return {
    "plugin-stub"
}