return {
	Scripts = {"diplomacy"}
}