return {
	Flags = {FULLINHERIT = "ENFORCER"}
}