return {
	Flags = {FULLINHERIT = "MEDIATOR"}
}