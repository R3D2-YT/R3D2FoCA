return {
	Flags = {FULLINHERIT = "ENDURANCE"}
}