return {
	Flags = {FULLINHERIT = "MAJESTIC"}
}