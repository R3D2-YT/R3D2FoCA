return {
	Flags = {FULLINHERIT = "ROHKEA"}
}