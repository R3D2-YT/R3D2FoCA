return {
	Flags = {FULLINHERIT = "ARMADIA"}
}