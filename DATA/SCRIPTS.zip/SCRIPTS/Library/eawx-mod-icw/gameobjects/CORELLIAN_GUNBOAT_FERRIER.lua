return {
	Scripts = {"boarding"}, 
	Fighters = {}
}