return {
	Flags = {FULLINHERIT = "DAUNTLESS"}
}