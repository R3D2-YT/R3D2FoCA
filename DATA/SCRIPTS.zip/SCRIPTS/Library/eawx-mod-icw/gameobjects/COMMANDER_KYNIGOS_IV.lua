return {
	Flags = {FULLINHERIT = "KYNIGOS"}
}