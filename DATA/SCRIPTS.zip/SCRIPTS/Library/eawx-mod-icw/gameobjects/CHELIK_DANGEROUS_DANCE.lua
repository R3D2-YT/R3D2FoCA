return {
	Flags = {FULLINHERIT = "BATTLEDRAGON"}
}